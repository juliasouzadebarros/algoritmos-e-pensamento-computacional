
#include <stdio.h>

int main() {
    int numero, i;
    FILE *arquivo;

    printf("Digite um numero inteiro: ");

    if (scanf("%d", &numero) != 1) {
        printf("Entrada invalida! Digite um numero inteiro.\n");
        return 1;
    }

    arquivo = fopen("tabuada.txt", "w");

    if (arquivo == NULL) {
        printf("Nao foi possivel criar o arquivo.\n");
        return 1;
    }

    for (i = 0; i <= 10; i++) {
        fprintf(arquivo, "%d * %d = %d\n",
                numero, i, numero * i);
    }

    fclose(arquivo);

    printf("Tabuada gerada com sucesso!\n");

    return 0;
}