#include <stdio.h>

int main() {
     
    char linha[100];
    FILE *arquivo;

    printf("Digite um numero inteiro: ");

    arquivo = fopen("tabuada.txt", "r");

    if (arquivo == NULL)
    {
        printf("Não foi possivel ler o arquivo.\n");
        return 1;
    }
    
    printf("Conteúdo do arquivo: \n");
    
    while(fgets(linha, sizeof(linha), arquivo) != NULL){
        printf("%s", linha);
    }

    return 0;
}