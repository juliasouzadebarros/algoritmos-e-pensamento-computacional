
#include <stdio.h>

int main() {
    int quantidade, i;
    char dia[15];
    float consumo;
    FILE *arquivo;

   arquivo = fopen("consumo.txt", "a");

    if (arquivo == NULL) {
        printf("Não foi possivel criar o arquivo.\n");
        return 1;
    }

    printf("Quantos registros deseja cadastrar?: ");
    scanf("%d", &quantidade);
    
    for (i=0; i<quantidade; i++){
        printf("\nRegistro %d\n", i+1);
        
        printf("Dia: ");
        scanf("%14s", dia);
        
        printf("Consumo: ");
        scanf("%f", &consumo);
        
        fprintf(arquivo, "%s %.2f\n", dia, consumo);
    }
    fclose(arquivo);
    printf ("Consumo gravado com sucesso!");
    
    return 0;
}